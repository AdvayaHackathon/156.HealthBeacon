
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const body = await req.json()
    const { symptoms, action, chatMessage, chatHistory } = body
    
    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY')
    if (!GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY not found in environment variables")
      throw new Error("API key for Gemini not configured")
    }

    if (action === 'chat') {
      console.log("Processing chat message:", chatMessage)
      
      // Prepare the prompt for Gemini chat
      const messages = chatHistory || []
      const userMessage = chatMessage || "Hello"
      
      const systemPrompt = 
        "You are MediGuide, a helpful medical assistant chatbot. " +
        "Your role is to help users understand their symptoms, guide them through using the symptom checker, " +
        "and provide general health information. You cannot diagnose conditions, but you can explain how " +
        "the symptom checker works and help users enter their symptoms correctly. " +
        "Keep responses concise, informative, and empathetic. Remind users that this is not a replacement for professional medical advice."
      
      // Call the Gemini API for chat
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts: [{ text: systemPrompt }]
              },
              ...messages.map((msg: any) => ({
                role: msg.role,
                parts: [{ text: msg.content }]
              })),
              {
                role: "user",
                parts: [{ text: userMessage }]
              }
            ],
            generationConfig: {
              temperature: 0.7,
              topP: 0.95,
              topK: 40,
              maxOutputTokens: 1024,
            },
          }),
        }
      )

      const data = await response.json()
      
      if (!response.ok) {
        console.error("Gemini API error:", data)
        throw new Error(`Gemini API error: ${data.error?.message || "Unknown error"}`)
      }

      let responseText = ""
      if (data.candidates && data.candidates[0]?.content?.parts) {
        responseText = data.candidates[0].content.parts[0].text
      } else {
        throw new Error("Unexpected response format from Gemini API")
      }

      return new Response(
        JSON.stringify({ response: responseText }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    } else {
      // Original symptom checker functionality
      if (!symptoms || symptoms.length === 0) {
        return new Response(
          JSON.stringify({ error: 'No symptoms provided' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      console.log("Processing symptoms:", symptoms)
      
      // Prepare the prompt for Gemini
      const symptomsList = symptoms.join(", ")
      const prompt = `Based on these symptoms: ${symptomsList}, provide a medical diagnosis with the following information for each of the top 3 possible conditions:
      1. Condition name
      2. Probability (as a decimal between 0 and 1)
      3. Severity (Mild, Moderate, or Severe)
      4. Brief description of the condition
      5. Recommended specialist to consult
      6. 4-5 recommendations for managing the condition
      
      Format your answer as a structured JSON object using this exact format:
      {
        "diagnoses": [
          {
            "condition": "Condition Name",
            "probability": 0.XX,
            "severity": "Severity Level",
            "description": "Description text",
            "specialist": "Specialist type",
            "recommendations": [
              "Recommendation 1",
              "Recommendation 2",
              "Recommendation 3",
              "Recommendation 4"
            ]
          },
          {...}
        ]
      }
      
      IMPORTANT: Return ONLY the JSON, nothing else.`

      // Call the Gemini API
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  { text: prompt }
                ]
              }
            ],
            generationConfig: {
              temperature: 0.4,
              topP: 0.95,
              topK: 40,
              maxOutputTokens: 2048,
            },
          }),
        }
      )

      const data = await response.json()
      
      if (!response.ok) {
        console.error("Gemini API error:", data)
        throw new Error(`Gemini API error: ${data.error?.message || "Unknown error"}`)
      }

      let resultText = ""
      if (data.candidates && data.candidates[0]?.content?.parts) {
        resultText = data.candidates[0].content.parts[0].text
      } else {
        throw new Error("Unexpected response format from Gemini API")
      }

      // Extract only the JSON part from the response
      let jsonMatch = resultText.match(/\{[\s\S]*\}/)
      let diagnoses

      if (jsonMatch) {
        try {
          const jsonData = JSON.parse(jsonMatch[0])
          diagnoses = jsonData.diagnoses
        } catch (e) {
          console.error("Error parsing Gemini response as JSON:", e)
          throw new Error("Failed to parse diagnosis data")
        }
      } else {
        console.error("Could not find JSON in Gemini response:", resultText)
        throw new Error("Invalid response format from diagnosis API")
      }

      // Fallback to mock data if parsing failed or diagnoses is empty
      if (!diagnoses || diagnoses.length === 0) {
        console.warn("Using fallback mock diagnoses data")
        diagnoses = [
          {
            condition: "Common Cold",
            probability: 0.85,
            severity: "Mild",
            description: "A viral infectious disease of the upper respiratory tract that primarily affects the nose and throat.",
            specialist: "General Practitioner",
            recommendations: [
              "Rest and stay hydrated",
              "Take over-the-counter pain relievers",
              "Use a humidifier",
              "Gargle with salt water"
            ]
          },
          {
            condition: "Seasonal Allergies",
            probability: 0.72,
            severity: "Mild",
            description: "An allergic reaction to pollen from trees, grasses, or weeds, or to airborne mold spores.",
            specialist: "Allergist",
            recommendations: [
              "Take antihistamines",
              "Avoid allergy triggers",
              "Use nasal sprays",
              "Keep windows closed during high pollen counts"
            ]
          },
          {
            condition: "Migraine",
            probability: 0.68,
            severity: "Moderate",
            description: "A neurological condition that causes recurring headaches, often with throbbing pain on one side of the head.",
            specialist: "Neurologist",
            recommendations: [
              "Rest in a quiet, dark room",
              "Apply cold or warm compresses",
              "Take prescription migraine medications if available",
              "Consider preventive treatments if migraines are frequent"
            ]
          }
        ]
      }

      return new Response(
        JSON.stringify({ diagnoses }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }
  } catch (error) {
    console.error("Error processing request:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
