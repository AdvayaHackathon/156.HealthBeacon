
// PDF generator utility for the symptom checker

// Function to format the date as MM/DD/YYYY
const formatDate = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
};

// Function to generate a PDF from diagnosis data
export const generateDiagnosisPDF = async (
  symptoms: string[],
  diagnoses: any[],
  chatMessages: { role: string; content: string; timestamp: Date }[] = []
) => {
  // We'll use an external library to dynamically import jspdf and its dependencies
  const { jsPDF } = await import('jspdf');
  const { autoTable } = await import('jspdf-autotable');
  
  // Create a new PDF document
  const doc = new jsPDF();

  // Add title
  doc.setFontSize(22);
  doc.setTextColor(0, 83, 156); // HealthBlue color
  doc.text('Medical Symptom Assessment', 105, 20, { align: 'center' });
  
  // Add date
  doc.setFontSize(12);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on: ${formatDate(new Date())}`, 105, 30, { align: 'center' });

  // Add symptoms section
  doc.setFontSize(16);
  doc.setTextColor(0, 83, 156);
  doc.text('Reported Symptoms', 20, 45);
  
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  
  // Create a bulleted list of symptoms
  let yPos = 55;
  symptoms.forEach(symptom => {
    doc.text(`• ${symptom}`, 25, yPos);
    yPos += 7;
  });

  // Add diagnoses section
  doc.setFontSize(16);
  doc.setTextColor(0, 83, 156);
  doc.text('Potential Conditions', 20, yPos + 10);
  
  // For each diagnosis, add a detailed section
  let currentY = yPos + 20;
  
  diagnoses.forEach((diagnosis, index) => {
    // If we're running out of space on the current page, create a new page
    if (currentY > 250) {
      doc.addPage();
      currentY = 20;
    }
    
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text(`${index + 1}. ${diagnosis.condition}`, 20, currentY);
    currentY += 7;
    
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    
    // Add probability
    doc.text(`Probability: ${Math.round(diagnosis.probability * 100)}%`, 25, currentY);
    currentY += 7;
    
    // Add severity with appropriate color
    doc.setTextColor(
      diagnosis.severity.toLowerCase() === 'mild' ? 0 : 
      diagnosis.severity.toLowerCase() === 'moderate' ? 255 : 255,
      diagnosis.severity.toLowerCase() === 'mild' ? 128 : 
      diagnosis.severity.toLowerCase() === 'moderate' ? 165 : 0,
      diagnosis.severity.toLowerCase() === 'mild' ? 0 : 
      diagnosis.severity.toLowerCase() === 'moderate' ? 0 : 0
    );
    doc.text(`Severity: ${diagnosis.severity}`, 25, currentY);
    currentY += 7;
    
    // Reset text color
    doc.setTextColor(100, 100, 100);
    
    // Add specialist
    doc.text(`Recommended specialist: ${diagnosis.specialist}`, 25, currentY);
    currentY += 7;
    
    // Add description
    doc.setTextColor(0, 0, 0);
    const descriptionLines = doc.splitTextToSize(diagnosis.description, 170);
    doc.text(descriptionLines, 25, currentY);
    currentY += (descriptionLines.length * 7);
    
    // Add recommendations
    doc.setTextColor(100, 100, 100);
    doc.text('Recommendations:', 25, currentY);
    currentY += 7;
    
    diagnosis.recommendations.forEach((rec: string) => {
      doc.text(`• ${rec}`, 30, currentY);
      currentY += 7;
    });
    
    currentY += 10; // Add some space between diagnoses
  });

  // Add chat summary if available
  if (chatMessages.length > 0) {
    // If we're running out of space on the current page, create a new page
    if (currentY > 220) {
      doc.addPage();
      currentY = 20;
    }
    
    doc.setFontSize(16);
    doc.setTextColor(0, 83, 156);
    doc.text('Chat Consultation Summary', 20, currentY);
    currentY += 10;
    
    // Insert chat as a table
    autoTable(doc, {
      startY: currentY,
      head: [['Time', 'Role', 'Message']],
      body: chatMessages.map(msg => [
        msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        msg.role.charAt(0).toUpperCase() + msg.role.slice(1),
        msg.content.substring(0, 60) + (msg.content.length > 60 ? '...' : '')
      ]),
      theme: 'grid',
      headStyles: { fillColor: [0, 83, 156] }
    });
  }

  // Add disclaimer
  doc.addPage();
  doc.setFontSize(14);
  doc.setTextColor(255, 0, 0);
  doc.text('IMPORTANT DISCLAIMER', 105, 20, { align: 'center' });
  
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  const disclaimer = 
    "This report is generated using an AI-based symptom checker and is intended for informational purposes only. " +
    "It does not constitute professional medical advice, diagnosis, or treatment. " +
    "The results provided are based on the symptoms you reported and should be used as a starting point for discussion with a healthcare professional. " +
    "Always consult with a qualified healthcare provider for proper diagnosis and treatment of medical conditions. " +
    "In case of a medical emergency, please call your local emergency services immediately. " +
    "By using this report, you acknowledge that you understand and agree to these terms.";
  
  const disclaimerLines = doc.splitTextToSize(disclaimer, 170);
  doc.text(disclaimerLines, 20, 40);

  // Save the PDF with a filename based on the date
  doc.save(`Medical_Assessment_${formatDate(new Date()).replace(/\//g, '-')}.pdf`);
};
