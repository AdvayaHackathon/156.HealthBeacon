
import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Send, X, MinusCircle, Maximize2, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ChatbotHelperProps {
  isOpen: boolean;
  onToggle: () => void;
  onMinimize: () => void;
  isMinimized: boolean;
}

const ChatbotHelper = ({ isOpen, onToggle, onMinimize, isMinimized }: ChatbotHelperProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize chat with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          role: 'assistant',
          content: "Hello! I'm MediGuide, your medical assistant. How can I help you today? You can ask me about using the symptom checker, understanding medical terms, or general health information.",
          timestamp: new Date()
        }
      ]);
    }
  }, []);

  // Auto-scroll to the most recent message
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      role: 'user' as const,
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Call our Supabase Edge Function with chat action
      const { data, error } = await supabase.functions.invoke('symptom-checker', {
        body: { 
          action: 'chat',
          chatMessage: inputMessage,
          chatHistory: messages.map(msg => ({
            role: msg.role,
            content: msg.content
          }))
        },
      });
      
      if (error) throw error;
      
      // Add the assistant's response to the chat
      setMessages(prev => [
        ...prev, 
        {
          role: 'assistant',
          content: data.response,
          timestamp: new Date()
        }
      ]);
    } catch (err) {
      console.error("Error in chat:", err);
      setMessages(prev => [
        ...prev, 
        {
          role: 'assistant',
          content: "I'm sorry, I encountered an error. Please try again later.",
          timestamp: new Date()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (isMinimized) {
    return (
      <button
        onClick={onMinimize}
        className="fixed bottom-4 right-4 bg-healthBlue p-3 rounded-full shadow-lg hover:bg-blue-600 transition-colors z-50 flex items-center space-x-2"
      >
        <MessageCircle size={24} className="text-white" />
      </button>
    );
  }

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-80 sm:w-96 bg-white rounded-lg shadow-xl border border-gray-200 flex flex-col z-50 max-h-[500px]">
      <div className="p-3 border-b flex justify-between items-center bg-healthBlue text-white rounded-t-lg">
        <div className="flex items-center">
          <MessageCircle size={20} className="mr-2" />
          <h3 className="font-medium">MediGuide Assistant</h3>
        </div>
        <div className="flex space-x-1">
          <button 
            onClick={onMinimize} 
            className="p-1 hover:bg-blue-600 rounded"
            aria-label="Minimize chat"
          >
            <MinusCircle size={18} />
          </button>
          <button 
            onClick={onToggle} 
            className="p-1 hover:bg-blue-600 rounded"
            aria-label="Close chat"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-3 bg-gray-50">
        {messages.map((message, index) => (
          <div 
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] p-3 rounded-lg ${
                message.role === 'user' 
                  ? 'bg-healthBlue text-white' 
                  : 'bg-white text-gray-800 border border-gray-200'
              }`}
            >
              <p className="whitespace-pre-wrap">{message.content}</p>
              <span className="text-xs opacity-70 mt-1 block">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white text-gray-800 border border-gray-200 p-3 rounded-lg">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 border-t">
        <div className="flex gap-2">
          <Textarea
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="resize-none min-h-[80px]"
            disabled={isLoading}
          />
          <Button 
            onClick={handleSendMessage}
            className="self-end bg-healthBlue hover:bg-blue-600"
            disabled={isLoading || !inputMessage.trim()}
            aria-label="Send message"
          >
            <Send size={18} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatbotHelper;
