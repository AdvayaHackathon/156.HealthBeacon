
import { Link } from 'react-router-dom';
import { Github, Linkedin, Twitter, Mail, Phone } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-50 text-gray-600 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="hover:text-healthBlue transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/symptom-checker" className="hover:text-healthBlue transition-colors">
                  Symptom Checker
                </Link>
              </li>
              <li>
                <Link to="/doctors" className="hover:text-healthBlue transition-colors">
                  Find Doctors
                </Link>
              </li>
              <li>
                <Link to="/health-locker" className="hover:text-healthBlue transition-colors">
                  Health Locker
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-healthBlue transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-healthBlue transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Our Services</h3>
            <ul className="space-y-2">
              <li className="hover:text-healthBlue transition-colors">AI Symptom Diagnosis</li>
              <li className="hover:text-healthBlue transition-colors">Doctor Recommendations</li>
              <li className="hover:text-healthBlue transition-colors">Digital Health Records</li>
              <li className="hover:text-healthBlue transition-colors">Medical Information</li>
              <li className="hover:text-healthBlue transition-colors">Appointment Scheduling</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Contact Information</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Mail size={16} className="text-healthBlue" />
                <span>support@healthmate.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone size={16} className="text-healthBlue" />
                <span>+1 (800) HEALTH</span>
              </li>
            </ul>
          </div>

          {/* Social & Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Connect With Us</h3>
            <div className="flex space-x-4 mb-6">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-healthBlue transition-colors">
                <Github size={20} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-healthBlue transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-healthBlue transition-colors">
                <Twitter size={20} />
              </a>
            </div>
            <p className="text-sm">
              Stay updated with our latest features and health tips.
            </p>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500 mb-4 md:mb-0">
            &copy; {currentYear} HealthMate. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            <Link to="/privacy" className="hover:text-healthBlue transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-healthBlue transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
