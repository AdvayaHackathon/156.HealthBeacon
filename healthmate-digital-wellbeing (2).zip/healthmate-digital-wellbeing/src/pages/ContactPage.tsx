
import { useState } from 'react';
import { Mail, Phone, MapPin, Send, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { toast } from 'sonner';
import MainLayout from '@/components/layout/MainLayout';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    // In a real app, this would send the form data to the backend
    console.log("Form submitted:", formData);
    
    // Show success message
    toast.success("Message sent successfully! We'll be in touch soon.");
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  const faqs = [
    {
      question: "How accurate is the symptom checker?",
      answer: "Our symptom checker uses advanced machine learning algorithms trained on extensive medical data. It typically achieves 85-90% accuracy in identifying common conditions. However, it's designed to be a preliminary tool and not a replacement for professional medical diagnosis."
    },
    {
      question: "Is my health data secure?",
      answer: "Absolutely. We implement bank-level encryption for all stored data and follow HIPAA compliance standards. Your health information is only accessible to you and the healthcare providers you explicitly authorize."
    },
    {
      question: "How do doctor recommendations work?",
      answer: "Based on your symptom analysis and location, our system recommends appropriate specialists. Recommendations factor in doctor specialties, patient ratings, and proximity to your location to provide the most relevant options."
    },
    {
      question: "Can I cancel or reschedule appointments?",
      answer: "Yes, you can cancel or reschedule appointments up to 24 hours before the scheduled time without any penalty. Simply navigate to your appointments in the user dashboard and select the reschedule or cancel option."
    },
    {
      question: "What file formats can I upload to my health locker?",
      answer: "You can upload PDF documents, images (JPG, PNG, GIF), and text files. The maximum file size is 10MB per document. We're working on expanding support for additional file formats."
    }
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-800">Contact Us</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Have questions or need support? Our team is here to help you with anything related to HealthMate.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Contact Form */}
            <div className="lg:w-2/3">
              <h2 className="text-2xl font-bold mb-6 text-gray-800">Send Us a Message</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name *
                    </label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email *
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="What's this regarding?"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message *
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="How can we help you?"
                    className="min-h-[150px]"
                    required
                  />
                </div>
                
                <div>
                  <Button type="submit" className="w-full md:w-auto bg-healthBlue hover:bg-blue-500">
                    <Send className="mr-2" size={16} />
                    Send Message
                  </Button>
                </div>
              </form>
            </div>
            
            {/* Contact Info */}
            <div className="lg:w-1/3">
              <h2 className="text-2xl font-bold mb-6 text-gray-800">Contact Information</h2>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-healthBlue bg-opacity-10 rounded-full p-3">
                    <Mail className="text-healthBlue" size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-1">Email</h3>
                    <p className="text-gray-600">support@healthmate.com</p>
                    <p className="text-gray-600">info@healthmate.com</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-healthBlue bg-opacity-10 rounded-full p-3">
                    <Phone className="text-healthBlue" size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-1">Phone</h3>
                    <p className="text-gray-600">+1 (800) HEALTH</p>
                    <p className="text-gray-600">Mon-Fri, 9am-5pm ET</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-healthBlue bg-opacity-10 rounded-full p-3">
                    <MapPin className="text-healthBlue" size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-1">Headquarters</h3>
                    <p className="text-gray-600">123 Health Street</p>
                    <p className="text-gray-600">San Francisco, CA 94103</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-10 bg-healthGray rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Support Hours</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Monday - Friday</span>
                    <span className="font-medium">9:00 AM - 5:00 PM ET</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Saturday</span>
                    <span className="font-medium">10:00 AM - 2:00 PM ET</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Sunday</span>
                    <span className="font-medium">Closed</span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-gray-500">
                  For urgent matters outside business hours, please use our emergency contact form.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-healthGray">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Find quick answers to common questions about HealthMate.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="bg-white rounded-xl overflow-hidden shadow-sm">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-gray-50">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
          
          <div className="text-center mt-10">
            <p className="text-gray-600 mb-4">
              Don't see your question here? Contact our support team for assistance.
            </p>
            <Button className="bg-healthBlue hover:bg-blue-500">
              View All FAQs
            </Button>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default ContactPage;
