
import { Link } from 'react-router-dom';
import { Stethoscope, Calendar, FileText, ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MainLayout from '@/components/layout/MainLayout';

const HomePage = () => {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight text-gray-800">
                Check Your Health. <br className="hidden md:block" />
                Book Care. <br className="hidden md:block" />
                Stay Organized.
              </h1>
              <p className="text-xl mb-8 text-gray-600 max-w-lg">
                HealthMate combines AI-powered symptom checking, doctor recommendations, and digital record keeping in one seamless platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/symptom-checker">
                  <Button className="bg-healthBlue hover:bg-blue-500 text-white font-semibold text-lg px-8 py-6">
                    Start Diagnosing
                    <ArrowRight className="ml-2" size={18} />
                  </Button>
                </Link>
                <Link to="/doctors">
                  <Button variant="outline" className="border-healthBlue text-healthBlue hover:bg-healthBlue hover:text-white font-semibold text-lg px-8 py-6">
                    Find Doctors
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                alt="Healthcare professionals"
                className="rounded-xl shadow-lg object-cover w-full max-h-[500px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">How HealthMate Works</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our comprehensive platform makes healthcare management simple and accessible.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Feature 1 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="bg-healthMint rounded-full w-16 h-16 flex items-center justify-center mb-6">
                <Stethoscope className="text-green-600" size={28} />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">AI Symptom Checker</h3>
              <p className="text-gray-600 mb-6">
                Input your symptoms and get AI-powered insights about possible conditions and their severity.
              </p>
              <Link to="/symptom-checker" className="text-healthBlue font-medium hover:underline flex items-center">
                Check Symptoms <ArrowRight size={16} className="ml-2" />
              </Link>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                <Calendar className="text-healthBlue" size={28} />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">Doctor Recommendations</h3>
              <p className="text-gray-600 mb-6">
                Find and book appointments with qualified specialists based on your diagnosed conditions.
              </p>
              <Link to="/doctors" className="text-healthBlue font-medium hover:underline flex items-center">
                Find Doctors <ArrowRight size={16} className="ml-2" />
              </Link>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                <FileText className="text-purple-600" size={28} />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">Digital Health Locker</h3>
              <p className="text-gray-600 mb-6">
                Securely store, manage, and share your medical records for more coordinated care.
              </p>
              <Link to="/health-locker" className="text-healthBlue font-medium hover:underline flex items-center">
                Manage Records <ArrowRight size={16} className="ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-healthGray py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0 md:pr-12">
              <h2 className="text-3xl font-bold mb-6 text-gray-800">Benefits of Using HealthMate</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <Check className="text-green-500" size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800">Early Disease Detection</h3>
                    <p className="text-gray-600">
                      Our AI technology helps identify potential health issues early, leading to better outcomes.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <Check className="text-green-500" size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800">Specialist Matching</h3>
                    <p className="text-gray-600">
                      We connect you to the right specialists based on your specific health needs.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <Check className="text-green-500" size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800">Organized Health Records</h3>
                    <p className="text-gray-600">
                      Keep all your medical documents in one secure, accessible place.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <Check className="text-green-500" size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800">Time Saving</h3>
                    <p className="text-gray-600">
                      Streamline your healthcare journey with our efficient digital tools.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                alt="Patient consulting with doctor" 
                className="rounded-xl shadow-lg w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-16 text-center text-gray-800">What Our Users Say</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="flex flex-col h-full">
                <div className="mb-6">
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                      </svg>
                    ))}
                  </div>
                  <p className="text-gray-600 italic mb-6">
                    "HealthMate's symptom checker identified my condition accurately, and the doctor they recommended was perfect for my needs. The appointment booking process was seamless."
                  </p>
                </div>
                <div className="mt-auto">
                  <p className="font-semibold text-gray-800">Sarah Johnson</p>
                  <p className="text-gray-500 text-sm">Marketing Director</p>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="flex flex-col h-full">
                <div className="mb-6">
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                      </svg>
                    ))}
                  </div>
                  <p className="text-gray-600 italic mb-6">
                    "The health locker feature has been a game-changer for managing my family's medical records. I no longer have to search through papers or remember details during doctor visits."
                  </p>
                </div>
                <div className="mt-auto">
                  <p className="font-semibold text-gray-800">Michael Chen</p>
                  <p className="text-gray-500 text-sm">Software Engineer</p>
                </div>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-xl shadow-md p-8 transition-all hover:shadow-lg">
              <div className="flex flex-col h-full">
                <div className="mb-6">
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                      </svg>
                    ))}
                  </div>
                  <p className="text-gray-600 italic mb-6">
                    "As a busy professional, having all my healthcare needs handled through one platform has been invaluable. HealthMate saves me time and gives me peace of mind."
                  </p>
                </div>
                <div className="mt-auto">
                  <p className="font-semibold text-gray-800">Emily Rodriguez</p>
                  <p className="text-gray-500 text-sm">Teacher</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-healthBlue text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to take control of your health?</h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Join thousands of users who trust HealthMate for their healthcare needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/login">
              <Button className="bg-white text-healthBlue hover:bg-gray-100 text-lg px-8 py-6 font-semibold">
                Create Free Account
              </Button>
            </Link>
            <Link to="/symptom-checker">
              <Button variant="outline" className="border-white text-white hover:bg-white hover:text-healthBlue text-lg px-8 py-6 font-semibold">
                Try Symptom Checker
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default HomePage;
