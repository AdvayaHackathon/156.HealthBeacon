import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X, UserCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const location = useLocation();
  
  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
      }
    );
    
    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    closeMenu();
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Symptom Checker', path: '/symptom-checker' },
    { name: 'Doctors', path: '/doctors' },
    { name: 'Health Locker', path: '/health-locker' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2" onClick={closeMenu}>
          <div className="font-bold text-2xl text-healthBlue">
            HealthMate
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`text-base font-medium transition-colors hover:text-healthBlue ${
                location.pathname === link.path ? 'text-healthBlue border-b-2 border-healthBlue' : 'text-gray-600'
              }`}
            >
              {link.name}
            </Link>
          ))}
        </nav>

        {/* User Authentication Button */}
        <div className="hidden md:block">
          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Hello, {user.email?.split('@')[0]}</span>
              <Button 
                variant="ghost" 
                className="flex items-center gap-1 text-gray-600 hover:text-healthBlue"
                onClick={handleLogout}
              >
                <UserCircle size={18} />
                Logout
              </Button>
            </div>
          ) : (
            <Link to="/login">
              <Button className="bg-healthBlue hover:bg-blue-500 text-white">
                Login / Sign Up
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-gray-600 hover:text-healthBlue focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <nav className="md:hidden fixed inset-0 z-40 bg-white pt-16 px-6 animate-fade-in">
          <div className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`text-lg font-medium transition-colors hover:text-healthBlue p-2 ${
                  location.pathname === link.path ? 'text-healthBlue bg-healthGray rounded-md' : 'text-gray-600'
                }`}
                onClick={closeMenu}
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-4 border-t border-gray-200">
              {user ? (
                <div className="flex flex-col gap-3">
                  <span className="text-sm text-gray-600">Logged in as: {user.email}</span>
                  <Button 
                    variant="destructive" 
                    className="w-full"
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </div>
              ) : (
                <Link to="/login" onClick={closeMenu}>
                  <Button className="w-full bg-healthBlue hover:bg-blue-500 text-white">
                    Login / Sign Up
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;
