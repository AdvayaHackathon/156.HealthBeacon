
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Pill, Check, X, ArrowRight, AlertCircle, Heart, Download, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import MainLayout from '@/components/layout/MainLayout';
import { supabase } from '@/integrations/supabase/client';
import ChatbotHelper from '@/components/ChatbotHelper';
import { generateDiagnosisPDF } from '@/utils/pdfGenerator';

// Mock data for common symptoms (would be replaced with API data)
const commonSymptoms = [
  "Fever", "Headache", "Cough", "Fatigue", "Nausea", 
  "Sore throat", "Runny nose", "Shortness of breath", 
  "Muscle pain", "Stomach pain", "Dizziness", "Chest pain",
  "Rash", "Vomiting", "Diarrhea", "Joint pain", "Loss of taste",
  "Loss of smell", "Chills", "Back pain"
];

const SymptomCheckerPage = () => {
  const [symptomText, setSymptomText] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [diagnoses, setDiagnoses] = useState<any[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isChatMinimized, setIsChatMinimized] = useState(false);
  const [pdfGenerating, setPdfGenerating] = useState(false);
  const [chatMessages, setChatMessages] = useState<any[]>([]);

  // Function to load the PDF libraries dynamically
  useEffect(() => {
    const preloadLibraries = async () => {
      try {
        // Preload the libraries
        await import('jspdf');
        await import('jspdf-autotable');
      } catch (err) {
        console.error("Error preloading PDF libraries:", err);
      }
    };
    
    preloadLibraries();
  }, []);

  const handleAddSymptom = (symptom: string) => {
    if (!selectedSymptoms.includes(symptom)) {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
    }
    setSymptomText('');
  };

  const handleRemoveSymptom = (symptom: string) => {
    setSelectedSymptoms(selectedSymptoms.filter(s => s !== symptom));
  };

  const handleSymptomSuggestionClick = (symptom: string) => {
    handleAddSymptom(symptom);
  };

  const handleDiagnose = async () => {
    if (selectedSymptoms.length === 0) return;
    
    setIsLoading(true);
    
    try {
      // Call our Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('symptom-checker', {
        body: { symptoms: selectedSymptoms },
      });
      
      if (error) throw error;
      
      setDiagnoses(data.diagnoses);
    } catch (err) {
      console.error("Error diagnosing symptoms:", err);
      // Use mock data as fallback
      const mockDiagnoses = [
        {
          condition: "Common Cold",
          probability: 0.85,
          severity: "Mild",
          description: "A viral infectious disease of the upper respiratory tract that primarily affects the nose and throat.",
          specialist: "General Practitioner",
          recommendations: [
            "Rest and stay hydrated",
            "Take over-the-counter pain relievers",
            "Use a humidifier",
            "Gargle with salt water"
          ]
        },
        {
          condition: "Seasonal Allergies",
          probability: 0.72,
          severity: "Mild",
          description: "An allergic reaction to pollen from trees, grasses, or weeds, or to airborne mold spores.",
          specialist: "Allergist",
          recommendations: [
            "Take antihistamines",
            "Avoid allergy triggers",
            "Use nasal sprays",
            "Keep windows closed during high pollen counts"
          ]
        },
        {
          condition: "Migraine",
          probability: 0.68,
          severity: "Moderate",
          description: "A neurological condition that causes recurring headaches, often with throbbing pain on one side of the head.",
          specialist: "Neurologist",
          recommendations: [
            "Rest in a quiet, dark room",
            "Apply cold or warm compresses",
            "Take prescription migraine medications if available",
            "Consider preventive treatments if migraines are frequent"
          ]
        }
      ];
      setDiagnoses(mockDiagnoses);
    } finally {
      setIsLoading(false);
    }
  };

  const resetDiagnosis = () => {
    setDiagnoses(null);
    setSelectedSymptoms([]);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'mild': return 'text-green-500';
      case 'moderate': return 'text-yellow-500';
      case 'severe': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
    setIsChatMinimized(false);
  };

  const toggleMinimizeChat = () => {
    setIsChatMinimized(!isChatMinimized);
  };

  const handleGeneratePDF = async () => {
    if (!diagnoses) return;
    
    setPdfGenerating(true);
    try {
      await generateDiagnosisPDF(selectedSymptoms, diagnoses, chatMessages);
    } catch (err) {
      console.error("Error generating PDF:", err);
    } finally {
      setPdfGenerating(false);
    }
  };

  const filteredSuggestions = commonSymptoms.filter(s => 
    s.toLowerCase().includes(symptomText.toLowerCase()) && 
    !selectedSymptoms.includes(s)
  );

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-8 inline-block">
            <Pill className="text-healthBlue" size={48} />
          </div>
          <h1 className="text-4xl font-bold mb-4 text-gray-800">AI Symptom Checker</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Describe your symptoms, and our AI will help identify possible conditions and provide recommendations.
          </p>
          <Button 
            onClick={toggleChat} 
            variant="outline" 
            className="mt-4 bg-white border-healthBlue text-healthBlue hover:bg-healthBlue hover:text-white"
          >
            <MessageCircle className="mr-2" size={16} /> Chat with Medical Assistant
          </Button>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {diagnoses ? (
              // Diagnosis Results
              <div className="animate-fade-in">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-2xl font-bold text-gray-800">Diagnostic Results</h2>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      onClick={handleGeneratePDF}
                      disabled={pdfGenerating}
                      className="flex items-center gap-2"
                    >
                      {pdfGenerating ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-healthBlue" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Generating PDF...
                        </>
                      ) : (
                        <>
                          <Download size={16} /> Download PDF Report
                        </>
                      )}
                    </Button>
                    <Button variant="outline" onClick={resetDiagnosis}>
                      <X size={16} className="mr-2" /> New Diagnosis
                    </Button>
                  </div>
                </div>

                <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h3 className="text-lg font-medium text-gray-800 mb-2">Based on your symptoms:</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedSymptoms.map(symptom => (
                      <Badge key={symptom} variant="secondary">
                        {symptom}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  {diagnoses.map((diagnosis, index) => (
                    <div key={index} className="border rounded-xl p-6 shadow-sm">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">{diagnosis.condition}</h3>
                          <div className="flex items-center mt-2">
                            <span className="text-gray-500 mr-2">Probability:</span>
                            <div className="w-24 h-2 bg-gray-200 rounded-full">
                              <div 
                                className="h-2 bg-healthBlue rounded-full" 
                                style={{ width: `${diagnosis.probability * 100}%` }}
                              ></div>
                            </div>
                            <span className="ml-2 text-sm">{Math.round(diagnosis.probability * 100)}%</span>
                          </div>
                        </div>
                        <div>
                          <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getSeverityColor(diagnosis.severity)} bg-opacity-10`}>
                            {diagnosis.severity} Severity
                          </span>
                        </div>
                      </div>

                      <p className="text-gray-600 mb-4">
                        {diagnosis.description}
                      </p>

                      <div className="mb-4">
                        <h4 className="font-semibold text-gray-700 mb-2">Recommended Specialist: {diagnosis.specialist}</h4>
                        <Link to={`/doctors?specialist=${encodeURIComponent(diagnosis.specialist)}`}>
                          <Button size="sm" className="mt-2 bg-healthBlue hover:bg-blue-500">
                            Find {diagnosis.specialist} <ArrowRight size={16} className="ml-2" />
                          </Button>
                        </Link>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-700 mb-2">Recommendations:</h4>
                        <ul className="space-y-2">
                          {diagnosis.recommendations.map((rec: string, i: number) => (
                            <li key={i} className="flex items-start">
                              <Check size={16} className="text-green-500 mr-2 mt-1" />
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start">
                    <AlertCircle size={20} className="text-yellow-500 mr-3 mt-1" />
                    <div>
                      <h4 className="text-lg font-medium text-gray-800">Important Note</h4>
                      <p className="text-gray-600">
                        This AI-generated diagnosis is not a substitute for professional medical advice. 
                        Always consult with a healthcare provider for proper diagnosis and treatment.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              // Symptom Input Form
              <div className="bg-white rounded-xl shadow-md p-8">
                <h2 className="text-2xl font-bold mb-6 text-gray-800">Enter Your Symptoms</h2>
                
                <div className="mb-6">
                  <label htmlFor="symptoms" className="block text-sm font-medium text-gray-700 mb-2">
                    Describe your symptoms
                  </label>
                  <Textarea 
                    id="symptoms"
                    placeholder="Example: I've had a headache and fever for the past two days..."
                    className="min-h-[120px]"
                    value={symptomText}
                    onChange={(e) => setSymptomText(e.target.value)}
                  />
                  <button 
                    className="mt-2 text-healthBlue hover:text-blue-700 text-sm font-medium flex items-center"
                    onClick={() => symptomText && handleAddSymptom(symptomText)}
                  >
                    <PlusIcon className="w-4 h-4 mr-1" /> Add to symptoms
                  </button>
                </div>

                {symptomText && filteredSuggestions.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Suggested symptoms:</h3>
                    <div className="flex flex-wrap gap-2">
                      {filteredSuggestions.slice(0, 8).map(suggestion => (
                        <Badge 
                          key={suggestion}
                          variant="outline"
                          className="cursor-pointer hover:bg-gray-100"
                          onClick={() => handleSymptomSuggestionClick(suggestion)}
                        >
                          + {suggestion}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Common symptoms:</h3>
                  <div className="flex flex-wrap gap-2">
                    {commonSymptoms.slice(0, 12).map(symptom => (
                      <Badge 
                        key={symptom}
                        variant="outline"
                        className="cursor-pointer hover:bg-gray-100"
                        onClick={() => handleSymptomSuggestionClick(symptom)}
                      >
                        + {symptom}
                      </Badge>
                    ))}
                  </div>
                </div>

                {selectedSymptoms.length > 0 && (
                  <div className="mb-8">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Your selected symptoms:</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedSymptoms.map(symptom => (
                        <Badge key={symptom} className="bg-healthBlue hover:bg-blue-600">
                          {symptom}
                          <button
                            className="ml-2 text-white hover:text-gray-100"
                            onClick={() => handleRemoveSymptom(symptom)}
                          >
                            <X size={14} />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <Button 
                  className="w-full bg-healthBlue hover:bg-blue-500"
                  disabled={selectedSymptoms.length === 0 || isLoading}
                  onClick={handleDiagnose}
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Analyzing Symptoms...
                    </>
                  ) : (
                    <>Diagnose Now</>
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Additional Information */}
      <section className="bg-healthGray py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <Heart className="mx-auto text-red-500 mb-4" size={36} />
              <h2 className="text-3xl font-bold mb-4 text-gray-800">How Our Symptom Checker Works</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our AI-powered system analyzes your symptoms and compares them with thousands of conditions to provide possible diagnoses.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="text-healthBlue font-bold text-2xl mb-3">01</div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Enter Symptoms</h3>
                <p className="text-gray-600">
                  Describe how you're feeling or select from common symptoms to get started.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="text-healthBlue font-bold text-2xl mb-3">02</div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">AI Analysis</h3>
                <p className="text-gray-600">
                  Our machine learning algorithms analyze your symptoms against our medical database.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="text-healthBlue font-bold text-2xl mb-3">03</div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Get Results</h3>
                <p className="text-gray-600">
                  Review possible conditions, recommended specialists, and next steps for your care.
                </p>
              </div>
            </div>

            <div className="mt-12 text-center">
              <p className="text-gray-500 italic">
                Remember: Our symptom checker provides informational purposes only and is not a substitute for professional medical advice.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Chatbot Helper Component */}
      {(isChatOpen || isChatMinimized) && (
        <ChatbotHelper 
          isOpen={isChatOpen} 
          onToggle={toggleChat}
          onMinimize={toggleMinimizeChat}
          isMinimized={isChatMinimized}
        />
      )}
    </MainLayout>
  );
};

// Replace the custom Plus component with a PlusIcon component that uses width and height instead of size
function PlusIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width={props.width || 24}
      height={props.height || 24}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="M12 5v14" />
    </svg>
  );
}

export default SymptomCheckerPage;
