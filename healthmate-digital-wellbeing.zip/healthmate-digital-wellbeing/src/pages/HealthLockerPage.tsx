
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Upload, Trash2, Copy, Share2, AlertTriangle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import MainLayout from '@/components/layout/MainLayout';

// Mock reports data
const initialReports = [
  {
    id: 1,
    name: "Blood Test Results",
    date: "2024-12-01",
    doctor: "Dr. Sarah Johnson",
    category: "Blood Test",
    fileUrl: "#",
    fileType: "pdf"
  },
  {
    id: 2,
    name: "Chest X-Ray",
    date: "2024-10-15",
    doctor: "Dr. Michael Chen",
    category: "Radiology",
    fileUrl: "#",
    fileType: "image"
  },
  {
    id: 3,
    name: "Annual Physical Results",
    date: "2024-09-03",
    doctor: "Dr. Lisa Patel",
    category: "General",
    fileUrl: "#",
    fileType: "pdf"
  }
];

const HealthLockerPage = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [reports, setReports] = useState(initialReports);
  const [healthMateId, setHealthMateId] = useState('HM12345678');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [reportToDelete, setReportToDelete] = useState<number | null>(null);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [uploadDetails, setUploadDetails] = useState({
    name: '',
    doctor: '',
    category: 'General'
  });

  useEffect(() => {
    const checkUser = async () => {
      const { data } = await supabase.auth.getUser();
      setUser(data.user);
      setIsLoading(false);
      
      if (!data.user) {
        navigate('/login', { state: { from: '/health-locker' } });
      }
    };
    
    checkUser();
  }, [navigate]);

  const handleDeleteReport = (id: number) => {
    setReportToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (reportToDelete !== null) {
      setReports(reports.filter(report => report.id !== reportToDelete));
      toast.success("Report deleted successfully");
      setIsDeleteModalOpen(false);
      setReportToDelete(null);
    }
  };

  const copyHealthMateId = () => {
    navigator.clipboard.writeText(healthMateId);
    toast.success("HealthMate ID copied to clipboard");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileToUpload(e.target.files[0]);
    }
  };

  const handleUpload = () => {
    if (!fileToUpload) {
      toast.error("Please select a file to upload");
      return;
    }

    if (!uploadDetails.name) {
      toast.error("Please enter a name for the report");
      return;
    }

    // In a real app, this would upload the file to storage
    // Here we'll just add it to our local state
    const newReport = {
      id: reports.length + 1,
      name: uploadDetails.name,
      date: new Date().toISOString().split('T')[0],
      doctor: uploadDetails.doctor || "Not specified",
      category: uploadDetails.category,
      fileUrl: "#",
      fileType: fileToUpload.type.includes('image') ? "image" : "pdf"
    };

    setReports([newReport, ...reports]);
    toast.success("Report uploaded successfully");
    setIsUploadModalOpen(false);
    setFileToUpload(null);
    setUploadDetails({
      name: '',
      doctor: '',
      category: 'General'
    });
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-healthBlue mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading health records...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-8 inline-block">
            <FileText className="text-healthBlue" size={48} />
          </div>
          <h1 className="text-4xl font-bold mb-4 text-gray-800">Your Digital Health Locker</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Securely store and manage all your medical records in one place.
          </p>
        </div>
      </section>

      {/* Health Locker Dashboard */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main Content Area */}
            <div className="lg:w-2/3">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">My Health Records</h2>
                <Button onClick={() => setIsUploadModalOpen(true)} className="bg-healthBlue hover:bg-blue-500">
                  <Upload className="mr-2" size={16} />
                  Upload New Report
                </Button>
              </div>

              {reports.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {reports.map(report => (
                    <Card key={report.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{report.name}</CardTitle>
                          <div className={`p-2 rounded-full ${
                            report.fileType === 'pdf' 
                              ? 'bg-red-100 text-red-500' 
                              : 'bg-purple-100 text-purple-500'
                          }`}>
                            {report.fileType === 'pdf' ? (
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                                <polyline points="14 2 14 8 20 8"/>
                                <path d="M9 15v-1h6m-3-3v7"/>
                              </svg>
                            ) : (
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                <circle cx="8.5" cy="8.5" r="1.5"/>
                                <polyline points="21 15 16 10 5 21"/>
                              </svg>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Date:</span>
                            <span>{new Date(report.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Doctor:</span>
                            <span>{report.doctor}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Category:</span>
                            <span>{report.category}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between border-t pt-4">
                        <Button variant="outline" className="text-healthBlue border-healthBlue">
                          View Report
                        </Button>
                        <Button 
                          variant="ghost" 
                          onClick={() => handleDeleteReport(report.id)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="mb-4">
                    <FileText className="mx-auto text-gray-400" size={48} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">No health records yet</h3>
                  <p className="text-gray-600 mb-6">
                    Upload your first medical report to get started.
                  </p>
                  <Button onClick={() => setIsUploadModalOpen(true)} className="bg-healthBlue hover:bg-blue-500">
                    <Plus className="mr-2" size={16} />
                    Add First Report
                  </Button>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:w-1/3">
              <div className="sticky top-24">
                {/* User Health ID Card */}
                <Card className="mb-6 bg-gradient-to-br from-healthBlue to-blue-600 text-white">
                  <CardHeader>
                    <CardTitle className="text-lg">Your HealthMate ID</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-white/20 rounded-lg p-4 backdrop-blur-sm">
                      <p className="text-2xl font-mono tracking-wider mb-1">{healthMateId}</p>
                      <p className="text-xs opacity-90">Share this ID with doctors to give them access to your records</p>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between gap-2">
                    <Button 
                      variant="secondary" 
                      className="w-1/2 bg-white/20 hover:bg-white/30 backdrop-blur-sm"
                      onClick={copyHealthMateId}
                    >
                      <Copy size={16} className="mr-2" />
                      Copy ID
                    </Button>
                    <Button 
                      variant="secondary" 
                      className="w-1/2 bg-white/20 hover:bg-white/30 backdrop-blur-sm"
                    >
                      <Share2 size={16} className="mr-2" />
                      Share
                    </Button>
                  </CardFooter>
                </Card>

                {/* Storage Info */}
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="text-lg">Storage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Used Space</span>
                        <span className="font-semibold">1.2 GB / 5 GB</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-healthBlue h-2 rounded-full" style={{ width: '24%' }}></div>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">
                      You're using 24% of your available storage.
                    </p>
                  </CardContent>
                </Card>

                {/* Privacy Notice */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <AlertTriangle className="text-yellow-500 mr-2" size={20} />
                      Privacy & Security
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Your health data is encrypted and stored securely. Only you and the healthcare providers you explicitly share with can access your information.
                    </p>
                    <div className="flex justify-between">
                      <Button variant="link" className="text-healthBlue p-0 h-auto">
                        Privacy Policy
                      </Button>
                      <Button variant="link" className="text-healthBlue p-0 h-auto">
                        Security Info
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Upload Report Modal */}
      <Dialog open={isUploadModalOpen} onOpenChange={setIsUploadModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Health Record</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <label htmlFor="reportName" className="text-sm font-medium">
                Report Name *
              </label>
              <input
                type="text"
                id="reportName"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={uploadDetails.name}
                onChange={(e) => setUploadDetails({...uploadDetails, name: e.target.value})}
                placeholder="e.g., Blood Test Results"
              />
            </div>
            
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <label htmlFor="doctorName" className="text-sm font-medium">
                Doctor Name
              </label>
              <input
                type="text"
                id="doctorName"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={uploadDetails.doctor}
                onChange={(e) => setUploadDetails({...uploadDetails, doctor: e.target.value})}
                placeholder="e.g., Dr. Sarah Johnson"
              />
            </div>
            
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <label htmlFor="category" className="text-sm font-medium">
                Category
              </label>
              <select
                id="category"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={uploadDetails.category}
                onChange={(e) => setUploadDetails({...uploadDetails, category: e.target.value})}
              >
                <option value="General">General</option>
                <option value="Blood Test">Blood Test</option>
                <option value="Radiology">Radiology</option>
                <option value="Cardiology">Cardiology</option>
                <option value="Neurology">Neurology</option>
                <option value="Orthopedics">Orthopedics</option>
              </select>
            </div>
            
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <label htmlFor="file" className="text-sm font-medium">
                Upload File *
              </label>
              <div className="flex items-center justify-center w-full">
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-8 h-8 mb-4 text-gray-500" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">PDF or image files (MAX. 10MB)</p>
                  </div>
                  <input 
                    id="file" 
                    type="file" 
                    className="hidden" 
                    accept=".pdf,image/*"
                    onChange={handleFileChange}
                  />
                </label>
              </div>
              {fileToUpload && (
                <p className="text-sm text-green-600 mt-2">
                  File selected: {fileToUpload.name}
                </p>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUploadModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpload} className="bg-healthBlue hover:bg-blue-500">
              Upload Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Report</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <p className="text-gray-700">
              Are you sure you want to delete this report? This action cannot be undone.
            </p>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
            >
              Delete Permanently
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default HealthLockerPage;
