
import { Users, Award, Heart } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';

const AboutPage = () => {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-8 inline-block">
            <Heart className="text-red-500" size={48} />
          </div>
          <h1 className="text-4xl font-bold mb-4 text-gray-800">About HealthMate</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            We're on a mission to make healthcare more accessible, intuitive, and efficient for everyone.
          </p>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0 md:pr-12">
              <h2 className="text-3xl font-bold mb-6 text-gray-800">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                At HealthMate, we believe that healthcare should be accessible, understandable, and convenient for everyone. We're dedicated to empowering individuals to take control of their health through technology.
              </p>
              <p className="text-lg text-gray-600">
                Our AI-powered platform helps users identify potential health concerns early, connect with the right specialists, and maintain organized medical records—all in one seamless experience.
              </p>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                alt="Healthcare professionals discussing"
                className="rounded-xl shadow-lg object-cover w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Story & Background */}
      <section className="bg-healthGray py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">Our Story</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              How HealthMate evolved from a hackathon project to a comprehensive healthcare platform.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="text-healthBlue font-bold text-2xl mb-3">2023</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">The Beginning</h3>
              <p className="text-gray-600">
                HealthMate was born at a healthcare hackathon where our founding team recognized the need for a more integrated approach to digital health management.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="text-healthBlue font-bold text-2xl mb-3">2024</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Development</h3>
              <p className="text-gray-600">
                We assembled a team of healthcare professionals, AI specialists, and developers to build a platform that addresses real user needs.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="text-healthBlue font-bold text-2xl mb-3">2025</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Launch & Growth</h3>
              <p className="text-gray-600">
                Today, HealthMate is helping thousands of users make better healthcare decisions and manage their medical information efficiently.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">Our Core Values</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do at HealthMate.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-healthBlue">
                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                  <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                  <path d="m9 14 2 2 4-4"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Accessibility</h3>
              <p className="text-gray-600">
                Making healthcare information and services available to everyone, regardless of location or background.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-green-600">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Privacy</h3>
              <p className="text-gray-600">
                Ensuring the highest standards of data security and confidentiality for our users' medical information.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-yellow-600">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="m4.93 4.93 14.14 14.14"></path>
                  <path d="M9 9h.01"></path>
                  <path d="M15 15h.01"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Innovation</h3>
              <p className="text-gray-600">
                Continuously improving our AI algorithms and features to provide cutting-edge healthcare solutions.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-purple-600">
                  <path d="M14 19c3.771 0 5.657 0 6.828-1.172C22 16.657 22 14.771 22 11c0-3.771 0-5.657-1.172-6.828C19.657 3 17.771 3 14 3h-4C6.229 3 4.343 3 3.172 4.172 2 5.343 2 7.229 2 11c0 3.771 0 5.657 1.172 6.828C4.343 19 6.229 19 10 19"></path>
                  <path d="m14 15-2 2-2-2"></path>
                  <path d="M12 17V7"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Empowerment</h3>
              <p className="text-gray-600">
                Giving users the tools and knowledge they need to make informed healthcare decisions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Recognition */}
      <section className="bg-healthGray py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-xl p-6 shadow-sm flex flex-col items-center text-center">
                  <Award className="text-healthBlue mb-4" size={40} />
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">Health Tech Innovator</h3>
                  <p className="text-sm text-gray-600">Digital Health Awards, 2024</p>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-sm flex flex-col items-center text-center">
                  <Users className="text-purple-600 mb-4" size={40} />
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">Best User Experience</h3>
                  <p className="text-sm text-gray-600">Healthcare UX Summit, 2025</p>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-sm flex flex-col items-center text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-500 mb-4 w-10 h-10">
                    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
                  </svg>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">Top Health Startup</h3>
                  <p className="text-sm text-gray-600">TechCrunch, 2024</p>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-sm flex flex-col items-center text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600 mb-4 w-10 h-10">
                    <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/>
                    <path d="m9 12 2 2 4-4"/>
                  </svg>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">Security Excellence</h3>
                  <p className="text-sm text-gray-600">Health Privacy Forum, 2025</p>
                </div>
              </div>
            </div>
            <div className="md:w-1/2 md:pl-12">
              <h2 className="text-3xl font-bold mb-6 text-gray-800">Recognition & Partners</h2>
              <p className="text-lg text-gray-600 mb-6">
                We're proud to be recognized by leading organizations in healthcare and technology for our innovation and impact.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Our partnerships with hospitals, medical practices, and research institutions help us continuously improve our services and expand our reach.
              </p>
              <p className="text-lg text-gray-600">
                Together with our partners, we're working toward a future where quality healthcare is more accessible and personalized for everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Partners / Trusted By Section */}
      <section className="py-16 border-t border-gray-200">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-12 text-gray-800">Trusted By</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
            <div className="grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
              <div className="h-12 flex items-center justify-center">
                <div className="font-bold text-xl text-gray-500">MedTech Labs</div>
              </div>
            </div>
            <div className="grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
              <div className="h-12 flex items-center justify-center">
                <div className="font-bold text-xl text-gray-500">City Hospital</div>
              </div>
            </div>
            <div className="grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
              <div className="h-12 flex items-center justify-center">
                <div className="font-bold text-xl text-gray-500">Health Research</div>
              </div>
            </div>
            <div className="grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all">
              <div className="h-12 flex items-center justify-center">
                <div className="font-bold text-xl text-gray-500">UniMed Center</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default AboutPage;
