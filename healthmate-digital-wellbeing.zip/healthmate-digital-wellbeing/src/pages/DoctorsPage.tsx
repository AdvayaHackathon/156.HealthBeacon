
import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, MapPin, Star, Phone, Calendar, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import MainLayout from '@/components/layout/MainLayout';

// Mock data for doctors (this would be replaced with API data)
const specialties = [
  "General Practitioner", "Cardiologist", "Dermatologist", 
  "Neurologist", "Pediatrician", "Psychiatrist", 
  "Orthopedist", "Gynecologist", "Urologist",
  "Endocrinologist", "Allergist", "Ophthalmologist"
];

const locations = [
  "New York, NY", "Los Angeles, CA", "Chicago, IL", 
  "Houston, TX", "Phoenix, AZ", "Philadelphia, PA",
  "San Antonio, TX", "San Diego, CA", "Dallas, TX", 
  "San Jose, CA"
];

const mockDoctors = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    specialty: "General Practitioner",
    location: "New York, NY",
    address: "123 Health St, New York, NY 10001",
    phone: "(212) 555-1234",
    rating: 4.9,
    reviewCount: 124,
    education: "Harvard Medical School",
    experience: "15 years",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-12", "2025-04-13", "2025-04-15", "2025-04-16"]
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    specialty: "Cardiologist",
    location: "Los Angeles, CA",
    address: "456 Heart Ave, Los Angeles, CA 90001",
    phone: "(310) 555-5678",
    rating: 4.8,
    reviewCount: 98,
    education: "Stanford University School of Medicine",
    experience: "12 years",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-12", "2025-04-14", "2025-04-17", "2025-04-18"]
  },
  {
    id: 3,
    name: "Dr. Emily Rodriguez",
    specialty: "Dermatologist",
    location: "Chicago, IL",
    address: "789 Skin Blvd, Chicago, IL 60601",
    phone: "(312) 555-9012",
    rating: 4.7,
    reviewCount: 86,
    education: "Northwestern University Feinberg School of Medicine",
    experience: "8 years",
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-13", "2025-04-14", "2025-04-16", "2025-04-19"]
  },
  {
    id: 4,
    name: "Dr. James Williams",
    specialty: "Neurologist",
    location: "Houston, TX",
    address: "101 Brain Dr, Houston, TX 77001",
    phone: "(713) 555-3456",
    rating: 4.9,
    reviewCount: 112,
    education: "Baylor College of Medicine",
    experience: "20 years",
    image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-12", "2025-04-15", "2025-04-17", "2025-04-20"]
  },
  {
    id: 5,
    name: "Dr. Lisa Patel",
    specialty: "Pediatrician",
    location: "Phoenix, AZ",
    address: "202 Kid Lane, Phoenix, AZ 85001",
    phone: "(602) 555-7890",
    rating: 4.8,
    reviewCount: 103,
    education: "University of Arizona College of Medicine",
    experience: "10 years",
    image: "https://images.unsplash.com/photo-1623854767648-e7bb8009f0db?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-13", "2025-04-16", "2025-04-18", "2025-04-21"]
  },
  {
    id: 6,
    name: "Dr. Robert Kim",
    specialty: "Psychiatrist",
    location: "Philadelphia, PA",
    address: "303 Mind St, Philadelphia, PA 19101",
    phone: "(215) 555-2345",
    rating: 4.6,
    reviewCount: 78,
    education: "University of Pennsylvania Perelman School of Medicine",
    experience: "14 years",
    image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    availableDates: ["2025-04-12", "2025-04-14", "2025-04-16", "2025-04-19"]
  }
];

const DoctorsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState('');
  const [filteredDoctors, setFilteredDoctors] = useState(mockDoctors);
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedRating, setSelectedRating] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Appointment booking modal
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  // Parse query parameters on component mount
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const specialistParam = params.get('specialist');
    
    if (specialistParam) {
      setSelectedSpecialty(specialistParam);
    }
  }, [location]);

  // Filter doctors when search criteria changes
  useEffect(() => {
    let filtered = mockDoctors;
    
    if (searchTerm) {
      filtered = filtered.filter(doctor => 
        doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedSpecialty) {
      filtered = filtered.filter(doctor => 
        doctor.specialty.toLowerCase() === selectedSpecialty.toLowerCase()
      );
    }
    
    if (selectedLocation) {
      filtered = filtered.filter(doctor => 
        doctor.location === selectedLocation
      );
    }
    
    if (selectedRating) {
      const minRating = parseFloat(selectedRating);
      filtered = filtered.filter(doctor => doctor.rating >= minRating);
    }
    
    setFilteredDoctors(filtered);
  }, [searchTerm, selectedSpecialty, selectedLocation, selectedRating]);

  const openBookingModal = (doctor: any) => {
    setSelectedDoctor(doctor);
    setBookingModalOpen(true);
  };

  const closeBookingModal = () => {
    setBookingModalOpen(false);
    setSelectedDoctor(null);
    setSelectedDate('');
    setSelectedTime('');
  };

  const bookAppointment = () => {
    // In a real app, this would send the booking data to the backend
    console.log("Booking appointment with:", selectedDoctor?.name);
    console.log("Date:", selectedDate);
    console.log("Time:", selectedTime);
    
    // Show confirmation and close modal
    alert(`Appointment scheduled with ${selectedDoctor?.name} on ${selectedDate} at ${selectedTime}`);
    closeBookingModal();
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedSpecialty('');
    setSelectedLocation('');
    setSelectedRating('');
    
    // Clear URL parameters
    navigate('/doctors');
  };

  const timeSlots = [
    "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", 
    "11:00 AM", "11:30 AM", "1:00 PM", "1:30 PM", 
    "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM"
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-healthGray to-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-800">Find the Right Doctor</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Connect with specialists who can provide the care you need, when and where you need it.
          </p>
        </div>
      </section>

      {/* Search Filters Section */}
      <section className="py-8 border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="w-full md:max-w-md relative">
              <Input
                type="text"
                placeholder="Search by name, specialty, or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={16} />
                Filters
              </Button>
              
              {(selectedSpecialty || selectedLocation || selectedRating) && (
                <Button 
                  variant="ghost" 
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={clearFilters}
                >
                  <X size={16} className="mr-1" />
                  Clear
                </Button>
              )}
            </div>
          </div>
          
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Specialty</label>
                <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Specialties" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Specialties</SelectItem>
                    {specialties.map(specialty => (
                      <SelectItem key={specialty} value={specialty}>{specialty}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Locations" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Locations</SelectItem>
                    {locations.map(location => (
                      <SelectItem key={location} value={location}>{location}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Rating</label>
                <Select value={selectedRating} onValueChange={setSelectedRating}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any Rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any Rating</SelectItem>
                    <SelectItem value="4.5">4.5+</SelectItem>
                    <SelectItem value="4.0">4.0+</SelectItem>
                    <SelectItem value="3.5">3.5+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          {/* Active filters */}
          {(selectedSpecialty || selectedLocation || selectedRating) && (
            <div className="flex flex-wrap gap-2 mt-4">
              {selectedSpecialty && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  Specialty: {selectedSpecialty}
                  <button onClick={() => setSelectedSpecialty('')}>
                    <X size={14} />
                  </button>
                </Badge>
              )}
              
              {selectedLocation && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  Location: {selectedLocation}
                  <button onClick={() => setSelectedLocation('')}>
                    <X size={14} />
                  </button>
                </Badge>
              )}
              
              {selectedRating && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  Rating: {selectedRating}+
                  <button onClick={() => setSelectedRating('')}>
                    <X size={14} />
                  </button>
                </Badge>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Doctors List Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {filteredDoctors.length > 0 ? (
            <>
              <div className="mb-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  {filteredDoctors.length} doctor{filteredDoctors.length !== 1 ? 's' : ''} found
                </h2>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredDoctors.map(doctor => (
                  <Card key={doctor.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <div className="flex flex-col sm:flex-row">
                        <div className="sm:w-1/3 overflow-hidden">
                          <img 
                            src={doctor.image} 
                            alt={doctor.name} 
                            className="w-full h-full object-cover sm:h-full"
                            style={{ minHeight: "200px" }}
                          />
                        </div>
                        <div className="sm:w-2/3 p-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-xl font-bold text-gray-800 mb-1">{doctor.name}</h3>
                              <p className="text-healthBlue font-medium">{doctor.specialty}</p>
                            </div>
                            <div className="flex items-center">
                              <Star className="text-yellow-400 mr-1" size={16} fill="currentColor" />
                              <span className="font-semibold">{doctor.rating}</span>
                              <span className="text-gray-500 text-sm ml-1">({doctor.reviewCount})</span>
                            </div>
                          </div>
                          
                          <div className="mt-4 space-y-2">
                            <div className="flex items-start">
                              <MapPin className="text-gray-500 mr-2 mt-1" size={16} />
                              <span className="text-gray-600">{doctor.address}</span>
                            </div>
                            <div className="flex items-center">
                              <Phone className="text-gray-500 mr-2" size={16} />
                              <span className="text-gray-600">{doctor.phone}</span>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <p className="text-sm text-gray-500">
                              <span className="font-medium">Education:</span> {doctor.education}
                            </p>
                            <p className="text-sm text-gray-500">
                              <span className="font-medium">Experience:</span> {doctor.experience}
                            </p>
                          </div>
                          
                          <Button 
                            className="mt-6 bg-healthBlue hover:bg-blue-500 w-full sm:w-auto"
                            onClick={() => openBookingModal(doctor)}
                          >
                            <Calendar size={16} className="mr-2" />
                            Book Appointment
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">😕</div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-2">No doctors found</h3>
              <p className="text-gray-600 mb-6">
                We couldn't find any doctors matching your search criteria.
              </p>
              <Button onClick={clearFilters}>
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Appointment Booking Modal */}
      <Dialog open={bookingModalOpen} onOpenChange={closeBookingModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Book an Appointment</DialogTitle>
          </DialogHeader>
          
          {selectedDoctor && (
            <div>
              <div className="flex items-center gap-4 mb-6">
                <img 
                  src={selectedDoctor.image} 
                  alt={selectedDoctor.name} 
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-bold text-gray-800">{selectedDoctor.name}</h3>
                  <p className="text-healthBlue">{selectedDoctor.specialty}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Select Date
                  </label>
                  <Select value={selectedDate} onValueChange={setSelectedDate}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a date" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedDoctor.availableDates.map((date: string) => (
                        <SelectItem key={date} value={date}>
                          {new Date(date).toLocaleDateString('en-US', { 
                            weekday: 'long', 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedDate && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Time
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {timeSlots.map(time => (
                        <button
                          key={time}
                          className={`p-2 text-sm rounded border ${
                            selectedTime === time 
                              ? 'bg-healthBlue text-white border-healthBlue' 
                              : 'border-gray-300 hover:border-healthBlue'
                          }`}
                          onClick={() => setSelectedTime(time)}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={closeBookingModal}>
              Cancel
            </Button>
            <Button 
              disabled={!selectedDate || !selectedTime}
              onClick={bookAppointment}
              className="bg-healthBlue hover:bg-blue-500"
            >
              Book Appointment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default DoctorsPage;
